<!-- Affichage de l'entête -->
<?php get_header(); ?>
<main>
<?php print ('<h1>Hello World</h1>'); ?>
</main>
<!-- Affichage du footer -->
<?php get_footer(); ?>
